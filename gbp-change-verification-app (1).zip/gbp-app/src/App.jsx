import React, { useState, useEffect, useRef, useMemo } from "react";
import Papa from "papaparse";
import * as XLSX from "xlsx";
import {
  LayoutDashboard, UploadCloud, Database, AlertTriangle, Users, TrendingUp,
  ScrollText, Settings as SettingsIcon, HelpCircle, Search, Download, RefreshCw,
  CheckCircle2, Clock, XCircle, CircleHelp, ChevronRight, X, Play, FileText,
  Sun, ArrowLeft, Info, Sparkles, ChevronDown, PlusCircle, Menu
} from "lucide-react";

/* ============================================================================
   GBP CHANGE VERIFICATION & MONITORING
   ----------------------------------------------------------------------------
   A verification/monitoring layer on top of the existing SI platform.
   This tool does NOT sync data. It compares an "expected change" against the
   live GBP snapshot and classifies it GREEN / YELLOW / RED / GRAY.
   ============================================================================ */

/* ---------------------------- CONSTANTS ---------------------------------- */

const CHANGE_TYPES = ["Phone", "Business Name", "Address", "Business Hours"];

const FIELD_KEY = {
  "Phone": "phone",
  "Business Name": "businessName",
  "Address": "address",
  "Business Hours": "hours",
};

const STATUS_META = {
  GREEN:  { label: "VERIFIED",           dot: "#16A34A", text: "#15803D", bg: "#ECFDF3", border: "#B7EFC5", icon: CheckCircle2 },
  YELLOW: { label: "PENDING",            dot: "#D97706", text: "#B45309", bg: "#FFFBEB", border: "#FDE9B8", icon: Clock },
  RED:    { label: "EXCEPTION",          dot: "#DC2626", text: "#B91C1C", bg: "#FEF2F2", border: "#F9C7C4", icon: XCircle },
  GRAY:   { label: "MATCHING REQUIRED",  dot: "#6B7280", text: "#4B5563", bg: "#F3F4F6", border: "#E2E4E8", icon: CircleHelp },
};

// Real-world default recheck schedule (used for "Next Check" display / Settings)
const DEFAULT_INTERVALS_MIN = [30, 120, 360, 60 * 18]; // 30m, 2h, 6h, ~next business day
const INTERVAL_LABELS = ["30 minutes", "2 hours", "6 hours", "Next business day"];

// Compressed timing so the recheck pipeline can be *watched* in a browser demo.
// This does not run once the tab is closed — see Help / Settings for the honest caveat.
const DEMO_SECONDS = [10, 18, 26, 34];

const PRIORITIES = ["Low", "Normal", "High", "Urgent"];

/* ---------------------------- UTILITIES ----------------------------------- */

let __id = 1;
const nextId = (p) => `${p}_${__id++}_${Math.random().toString(36).slice(2, 7)}`;

function fmtDateTime(d) {
  if (!d) return "-";
  const dt = d instanceof Date ? d : new Date(d);
  if (isNaN(dt.getTime())) return "-";
  return dt.toLocaleString("en-IN", { day: "2-digit", month: "short", hour: "numeric", minute: "2-digit", hour12: true });
}
function fmtDateTimeFull(d) {
  if (!d) return "-";
  const dt = d instanceof Date ? d : new Date(d);
  if (isNaN(dt.getTime())) return "-";
  return dt.toLocaleString("en-IN", { day: "2-digit", month: "long", year: "numeric", hour: "numeric", minute: "2-digit", hour12: true });
}
function addMinutes(d, m) { return new Date(d.getTime() + m * 60000); }
function minutesBetween(a, b) { return Math.round((b.getTime() - a.getTime()) / 60000); }
function fmtDuration(mins) {
  if (mins == null || isNaN(mins)) return "-";
  if (mins < 60) return `${mins}m`;
  const h = Math.floor(mins / 60), m = mins % 60;
  return m ? `${h}h ${m}m` : `${h}h`;
}

/* --------------------------- NORMALIZATION -------------------------------- */

function normalizePhone(v) {
  if (!v) return "";
  let digits = String(v).replace(/[^\d]/g, "");
  if (digits.length === 12 && digits.startsWith("91")) digits = digits.slice(2);
  if (digits.length === 11 && digits.startsWith("0")) digits = digits.slice(1);
  return digits;
}
function normalizeName(v) {
  if (!v) return "";
  return String(v).trim().replace(/\s+/g, " ").toLowerCase();
}
function normalizeAddress(v) {
  if (!v) return "";
  return String(v)
    .trim().toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/[.,]/g, "")
    .replace(/\bstreet\b/g, "st")
    .replace(/\broad\b/g, "rd")
    .replace(/\bfloor\b/g, "fl");
}
function normalizeHours(v) {
  if (!v) return "";
  return String(v)
    .trim().toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/[–—]/g, "-")
    .replace(/\./g, "")
    .replace(/\bam\b/g, "am").replace(/\bpm\b/g, "pm");
}
const NORMALIZER = {
  "Phone": normalizePhone,
  "Business Name": normalizeName,
  "Address": normalizeAddress,
  "Business Hours": normalizeHours,
};

// simple bigram Dice-coefficient similarity, used only for fuzzy name matching
function similarity(a, b) {
  if (!a || !b) return 0;
  if (a === b) return 1;
  const bigrams = (s) => {
    const out = [];
    for (let i = 0; i < s.length - 1; i++) out.push(s.slice(i, i + 2));
    return out;
  };
  const A = bigrams(a), B = bigrams(b);
  if (!A.length || !B.length) return 0;
  const map = new Map();
  A.forEach((g) => map.set(g, (map.get(g) || 0) + 1));
  let hits = 0;
  B.forEach((g) => {
    const c = map.get(g) || 0;
    if (c > 0) { hits++; map.set(g, c - 1); }
  });
  return (2 * hits) / (A.length + B.length);
}

/* --------------------------- MATCHING ENGINE ------------------------------- */

function matchLocation(change, gbpLocations) {
  if (change.gbpLocationId) {
    const m = gbpLocations.find(g => g.gbpLocationId && g.gbpLocationId.trim().toLowerCase() === change.gbpLocationId.trim().toLowerCase());
    if (m) return { location: m, method: "GBP Location ID", confidence: "high" };
  }
  if (change.storeCode) {
    const m = gbpLocations.find(g => g.storeCode && g.storeCode.trim().toLowerCase() === change.storeCode.trim().toLowerCase());
    if (m) return { location: m, method: "Store Code", confidence: "high" };
  }
  if (change.locationId) {
    const m = gbpLocations.find(g => g.internalLocationId && g.internalLocationId.trim().toLowerCase() === change.locationId.trim().toLowerCase());
    if (m) return { location: m, method: "Internal Location ID", confidence: "high" };
  }
  if (change.changeType === "Phone" && change.oldValue) {
    const norm = normalizePhone(change.oldValue);
    if (norm) {
      const m = gbpLocations.find(g => normalizePhone(g.phone) === norm);
      if (m) return { location: m, method: "Phone", confidence: "high" };
    }
  }
  if (change.branchName) {
    let best = null, bestScore = 0;
    gbpLocations.forEach(g => {
      const nameScore = similarity(normalizeName(change.branchName), normalizeName(g.businessName));
      const addrScore = change.address ? similarity(normalizeAddress(change.address), normalizeAddress(g.address)) : 0;
      const combined = change.address ? nameScore * 0.6 + addrScore * 0.4 : nameScore;
      if (combined > bestScore) { bestScore = combined; best = g; }
    });
    if (best) {
      if (bestScore >= 0.9) return { location: best, method: "Business Name + Address", confidence: "high" };
      if (bestScore >= 0.6) return { location: best, method: "Business Name + Address", confidence: "low" };
    }
  }
  return { location: null, method: "No Match Found", confidence: "none" };
}

/* --------------------------- GBP DATA PROVIDER -----------------------------
   Abstraction layer. MVP implementation reads from an in-memory array that was
   populated by file upload. A future GoogleBusinessProfileAPIProvider could
   implement the same three methods against the live GBP API without any other
   part of the application changing.
------------------------------------------------------------------------------ */
class FileUploadGBPProvider {
  constructor(locations) { this.locations = locations || []; }
  getLocations() { return this.locations; }
  getLocation(gbpLocationId) { return this.locations.find(l => l.gbpLocationId === gbpLocationId) || null; }
  getLocationField(gbpLocationId, field) {
    const loc = this.getLocation(gbpLocationId);
    return loc ? loc[field] : undefined;
  }
  get sourceLabel() { return "GBP Data Provider (File Upload)"; }
}

/* ------------------------------ DEMO DATA ---------------------------------- */

const CITIES = [
  "Kochi","Pune","Mumbai","Chennai","Bangalore","Hyderabad","Delhi","Kolkata",
  "Ahmedabad","Jaipur","Lucknow","Indore","Nagpur","Surat","Coimbatore",
  "Vadodara","Bhopal","Patna","Chandigarh","Nashik",
];
const CITY_CODE = {
  Kochi:"KOC",Pune:"PUN",Mumbai:"MUM",Chennai:"CHE",Bangalore:"BLR",Hyderabad:"HYD",
  Delhi:"DEL",Kolkata:"KOL",Ahmedabad:"AMD",Jaipur:"JAI",Lucknow:"LKO",Indore:"IND",
  Nagpur:"NAG",Surat:"SUR",Coimbatore:"CBE",Vadodara:"BAR",Bhopal:"BHO",Patna:"PAT",
  Chandigarh:"CHD",Nashik:"NAS",
};

function buildDemoGbpLocations() {
  return CITIES.map((city, i) => {
    const code = CITY_CODE[city];
    return {
      gbpLocationId: `GBP-ICL-${code}`,
      storeCode: `ICL-KL-${code}-00${(i % 9) + 1}`,
      internalLocationId: `ICL-${code}-001`,
      businessName: `ICL Fincorp - ${city}`,
      phone: `98765${(43200 + i).toString()}`,
      address: `${100 + i}, MG Road, ${city}`,
      hours: "Mon-Sat 9:30 AM-6:30 PM, Sun Closed",
      lat: 10 + i * 0.4,
      lng: 76 + i * 0.3,
    };
  });
}

// hand-authored seed records so the demo narrates the exact scenarios in the brief
function buildDemoRecords(gbpLocations) {
  const g = (code) => gbpLocations.find(l => l.gbpLocationId === `GBP-ICL-${code}`);
  const today = new Date();
  today.setHours(10, 5, 0, 0);
  const mk = (overrides) => {
    const base = {
      id: nextId("rec"),
      client: "ICL Fincorp",
      priority: "Normal",
      requestedBy: "R. Menon",
      unexpectedChange: null,
      isDemo: true,
      source: "GBP Data Provider (File Upload)",
    };
    return { ...base, ...overrides };
  };

  const records = [];

  // 1. Kochi phone — GREEN, matches the worked example in the brief exactly
  {
    const loc = g("KOC");
    const created = new Date(today); created.setHours(10, 5, 0, 0);
    const c1 = new Date(today); c1.setHours(10, 35, 0, 0);
    const c2 = new Date(today); c2.setHours(12, 5, 0, 0);
    const c3 = new Date(today); c3.setHours(15, 5, 0, 0);
    loc.phone = "9876543210";
    records.push(mk({
      client: "ICL Fincorp", branch: "Kochi", locationId: "ICL-KL-KOC-001",
      changeType: "Phone", oldValue: "9876543200", expectedValue: "9876543210",
      matchedLocationId: loc.gbpLocationId, matchMethod: "Store Code", matchConfidence: "high",
      currentGbpValue: loc.phone, attempts: 3, status: "GREEN",
      createdAt: created, verifiedAt: c3, nextCheckDemoAt: null, requestDate: "2026-07-31",
      checks: [
        { n: 0, time: created, event: "Change request created" },
        { n: 1, time: c1, gbpValue: "9876543200", result: "PENDING" },
        { n: 2, time: c2, gbpValue: "9876543200", result: "PENDING" },
        { n: 3, time: c3, gbpValue: "9876543210", result: "VERIFIED" },
      ],
    }));
  }

  // 2. Pune phone — RED, matches the worked example exactly
  {
    const loc = g("PUN");
    loc.phone = "9876543200"; // still old — this is why it's an exception
    const created = new Date(today); created.setHours(10, 30, 0, 0);
    const c1 = new Date(today); c1.setHours(11, 0, 0, 0);
    const c2 = new Date(today); c2.setHours(13, 0, 0, 0);
    const c3 = new Date(today); c3.setHours(19, 0, 0, 0);
    const c4 = new Date(today); c4.setHours(15, 30, 0, 0);
    records.push(mk({
      client: "ICL Fincorp", branch: "Pune", locationId: "ICL-KL-PUN-004",
      changeType: "Phone", oldValue: "9876543200", expectedValue: "9876543222",
      matchedLocationId: loc.gbpLocationId, matchMethod: "Store Code", matchConfidence: "high",
      currentGbpValue: loc.phone, attempts: 4, status: "RED",
      createdAt: created, requestDate: "2026-07-31",
      checks: [
        { n: 0, time: created, event: "Change request created" },
        { n: 1, time: c1, gbpValue: "9876543200", result: "PENDING" },
        { n: 2, time: c2, gbpValue: "9876543200", result: "PENDING" },
        { n: 3, time: c3, gbpValue: "9876543200", result: "PENDING" },
        { n: 4, time: c4, gbpValue: "9876543200", result: "EXCEPTION" },
      ],
      reviewed: false, notes: [],
    }));
  }

  // 3. Mumbai business hours — YELLOW, live-pending, will tick in the demo clock
  {
    const loc = g("MUM");
    loc.hours = "Mon-Sat 9:30 AM-6:30 PM, Sun Closed"; // unchanged so far
    const created = new Date(); created.setMinutes(created.getMinutes() - 12);
    const c1 = new Date(); c1.setMinutes(c1.getMinutes() - 2);
    records.push(mk({
      client: "ICL Fincorp", branch: "Mumbai", locationId: "ICL-KL-MUM-002",
      changeType: "Business Hours", oldValue: "Mon-Sat 9:30 AM-6:30 PM, Sun Closed",
      expectedValue: "Mon-Sat 9:00 AM-7:00 PM, Sun 10:00 AM-2:00 PM",
      matchedLocationId: loc.gbpLocationId, matchMethod: "GBP Location ID", matchConfidence: "high",
      currentGbpValue: loc.hours, attempts: 1, status: "YELLOW",
      createdAt: created, requestDate: "2026-08-03",
      nextCheckDemoAt: Date.now() + DEMO_SECONDS[1] * 1000,
      checks: [
        { n: 0, time: created, event: "Change request created" },
        { n: 1, time: c1, gbpValue: loc.hours, result: "PENDING" },
      ],
      reviewed: false, notes: [],
    }));
  }

  // 4. Chennai address — GRAY, low-confidence match (no store code / gbp id given)
  {
    const created = new Date(); created.setHours(9, 50, 0, 0);
    records.push(mk({
      client: "ICL Fincorp", branch: "Chennai Annex", locationId: "",
      changeType: "Address", oldValue: "12, Anna Salai, Chennai",
      expectedValue: "14, Anna Salai, Chennai",
      matchedLocationId: null, matchMethod: "No Match Found", matchConfidence: "none",
      currentGbpValue: null, attempts: 0, status: "GRAY",
      createdAt: created, requestDate: "2026-08-01",
      checks: [{ n: 0, time: created, event: "Change request created — no confident location match" }],
      reviewed: false, notes: [],
    }));
  }

  // 5. Bangalore phone — GREEN but with an unexpected business-name change flagged
  {
    const loc = g("BLR");
    loc.phone = "9876543214";
    loc.businessName = "ICL Fincorp Pvt Ltd - Bangalore Whitefield"; // drifted from SI's "Bangalore"
    const created = new Date(today); created.setHours(9, 0, 0, 0);
    const c1 = new Date(today); c1.setHours(9, 40, 0, 0);
    records.push(mk({
      client: "ICL Fincorp", branch: "Bangalore", locationId: "ICL-KL-BLR-005",
      changeType: "Phone", oldValue: "9876543204", expectedValue: "9876543214",
      matchedLocationId: loc.gbpLocationId, matchMethod: "Store Code", matchConfidence: "high",
      currentGbpValue: loc.phone, attempts: 1, status: "GREEN",
      createdAt: created, verifiedAt: c1, requestDate: "2026-07-30",
      checks: [
        { n: 0, time: created, event: "Change request created" },
        { n: 1, time: c1, gbpValue: loc.phone, result: "VERIFIED" },
      ],
      unexpectedChange: { field: "Business Name", from: "ICL Fincorp - Bangalore", to: loc.businessName },
      reviewed: false, notes: [],
    }));
  }

  // 6. Hyderabad business name — GREEN
  {
    const loc = g("HYD");
    loc.businessName = "ICL Fincorp Limited - Hyderabad";
    const created = new Date(today); created.setHours(8, 30, 0, 0);
    const c1 = new Date(today); c1.setHours(9, 5, 0, 0);
    records.push(mk({
      client: "ICL Fincorp", branch: "Hyderabad", locationId: "ICL-KL-HYD-006",
      changeType: "Business Name", oldValue: "ICL Fincorp - Hyderabad",
      expectedValue: "ICL Fincorp Limited - Hyderabad",
      matchedLocationId: loc.gbpLocationId, matchMethod: "GBP Location ID", matchConfidence: "high",
      currentGbpValue: loc.businessName, attempts: 1, status: "GREEN",
      createdAt: created, verifiedAt: c1, requestDate: "2026-07-29",
      checks: [
        { n: 0, time: created, event: "Change request created" },
        { n: 1, time: c1, gbpValue: loc.businessName, result: "VERIFIED" },
      ],
      reviewed: false, notes: [],
    }));
  }

  // 7. Kolkata address — RED
  {
    const loc = g("KOL");
    const created = new Date(today); created.setHours(9, 15, 0, 0);
    const c1 = new Date(today); c1.setHours(9, 45, 0, 0);
    const c2 = new Date(today); c2.setHours(11, 45, 0, 0);
    const c3 = new Date(today); c3.setHours(17, 45, 0, 0);
    const c4 = new Date(today); c4.setHours(14, 0, 0, 0);
    records.push(mk({
      client: "ICL Fincorp", branch: "Kolkata", locationId: "ICL-KL-KOL-007",
      changeType: "Address", oldValue: "107, MG Road, Kolkata", expectedValue: "45, Park Street, Kolkata",
      matchedLocationId: loc.gbpLocationId, matchMethod: "Store Code", matchConfidence: "high",
      currentGbpValue: loc.address, attempts: 4, status: "RED",
      createdAt: created, requestDate: "2026-07-28",
      checks: [
        { n: 0, time: created, event: "Change request created" },
        { n: 1, time: c1, gbpValue: loc.address, result: "PENDING" },
        { n: 2, time: c2, gbpValue: loc.address, result: "PENDING" },
        { n: 3, time: c3, gbpValue: loc.address, result: "PENDING" },
        { n: 4, time: c4, gbpValue: loc.address, result: "EXCEPTION" },
      ],
      reviewed: false, notes: [],
    }));
  }

  // 8. Ahmedabad phone — YELLOW, fewer attempts so far, live-ticking
  {
    const loc = g("AMD");
    const created = new Date(); created.setMinutes(created.getMinutes() - 4);
    records.push(mk({
      client: "ICL Fincorp", branch: "Ahmedabad", locationId: "ICL-KL-AMD-008",
      changeType: "Phone", oldValue: "9876543208", expectedValue: "9876543299",
      matchedLocationId: loc.gbpLocationId, matchMethod: "Store Code", matchConfidence: "high",
      currentGbpValue: loc.phone, attempts: 0, status: "YELLOW",
      createdAt: created, requestDate: "2026-08-03",
      nextCheckDemoAt: Date.now() + DEMO_SECONDS[0] * 1000,
      checks: [{ n: 0, time: created, event: "Change request created" }],
      reviewed: false, notes: [],
    }));
  }

  // 9. Delhi address — GREEN
  {
    const loc = g("DEL");
    loc.address = "22, Connaught Place, Delhi";
    const created = new Date(today); created.setHours(8, 0, 0, 0);
    const c1 = new Date(today); c1.setHours(8, 35, 0, 0);
    records.push(mk({
      client: "ICL Fincorp", branch: "Delhi", locationId: "ICL-KL-DEL-009",
      changeType: "Address", oldValue: "19, Connaught Place, Delhi", expectedValue: "22, Connaught Place, Delhi",
      matchedLocationId: loc.gbpLocationId, matchMethod: "GBP Location ID", matchConfidence: "high",
      currentGbpValue: loc.address, attempts: 1, status: "GREEN",
      createdAt: created, verifiedAt: c1, requestDate: "2026-07-27",
      checks: [
        { n: 0, time: created, event: "Change request created" },
        { n: 1, time: c1, gbpValue: loc.address, result: "VERIFIED" },
      ],
      reviewed: false, notes: [],
    }));
  }

  // 10. Jaipur hours — RED, already reviewed (for exception-management demo)
  {
    const loc = g("JAI");
    const created = new Date(today); created.setHours(7, 0, 0, 0);
    const c1 = new Date(today); c1.setHours(7, 30, 0, 0);
    const c2 = new Date(today); c2.setHours(9, 30, 0, 0);
    const c3 = new Date(today); c3.setHours(13, 30, 0, 0);
    const c4 = new Date(today); c4.setHours(9, 0, 0, 0);
    records.push(mk({
      client: "ICL Fincorp", branch: "Jaipur", locationId: "ICL-KL-JAI-010",
      changeType: "Business Hours", oldValue: "Mon-Sat 9:30 AM-6:30 PM, Sun Closed",
      expectedValue: "Mon-Sun 9:00 AM-9:00 PM",
      matchedLocationId: loc.gbpLocationId, matchMethod: "Store Code", matchConfidence: "high",
      currentGbpValue: loc.hours, attempts: 4, status: "RED",
      createdAt: created, requestDate: "2026-07-26",
      checks: [
        { n: 0, time: created, event: "Change request created" },
        { n: 1, time: c1, gbpValue: loc.hours, result: "PENDING" },
        { n: 2, time: c2, gbpValue: loc.hours, result: "PENDING" },
        { n: 3, time: c3, gbpValue: loc.hours, result: "PENDING" },
        { n: 4, time: c4, gbpValue: loc.hours, result: "EXCEPTION" },
      ],
      reviewed: true, notes: [{ time: c4, text: "Confirmed with CSM — GBP change was never submitted on Google's side. Re-requesting.", author: "P. Sharma" }],
    }));
  }

  return records;
}

// A handful of *unprocessed* expected-change rows so "RUN VERIFICATION" has
// something real to do live in the demo.
function buildDemoUnprocessedChanges(gbpLocations) {
  const g = (code) => gbpLocations.find(l => l.gbpLocationId === `GBP-ICL-${code}`);
  const rows = [
    { city: "Lucknow", code: "LKO", changeType: "Phone", newSuffix: "543280" },
    { city: "Indore", code: "IND", changeType: "Business Name", newVal: "ICL Fincorp Pvt Ltd - Indore" },
    { city: "Nagpur", code: "NAG", changeType: "Address", newVal: "9, Civil Lines, Nagpur" },
    { city: "Surat", code: "SUR", changeType: "Business Hours", newVal: "Mon-Sat 10:00 AM-7:00 PM, Sun Closed" },
    { city: "Coimbatore", code: "CBE", changeType: "Phone", newSuffix: "543294" },
    { city: "Vadodara", code: "BAR", changeType: "Phone", newSuffix: "543295" },
  ];
  return rows.map((r, i) => {
    const loc = g(r.code);
    const oldValue = loc[FIELD_KEY[r.changeType]];
    const expectedNewValue = r.newVal || `98765${r.newSuffix}`;
    return {
      id: nextId("chg"),
      clientName: "ICL Fincorp",
      locationId: loc.internalLocationId,
      storeCode: loc.storeCode,
      branchName: r.city,
      gbpLocationId: loc.gbpLocationId,
      changeType: r.changeType,
      oldValue,
      expectedNewValue,
      requestDate: "2026-08-03",
      requestedBy: "R. Menon",
      priority: i % 3 === 0 ? "High" : "Normal",
    };
  });
}

/* ------------------------- FILE PARSING HELPERS ---------------------------- */

const EXPECTED_ALIASES = {
  clientName: ["client name", "client"],
  locationId: ["location id", "internal location id"],
  storeCode: ["store code"],
  branchName: ["branch name", "branch"],
  gbpLocationId: ["gbp location id", "gbp id"],
  changeType: ["change type"],
  oldValue: ["old value"],
  expectedNewValue: ["expected new value", "expected value", "new value"],
  requestDate: ["request date"],
  requestedBy: ["requested by"],
  priority: ["priority"],
};
const GBP_ALIASES = {
  gbpLocationId: ["gbp location id", "gbp id"],
  storeCode: ["store code"],
  internalLocationId: ["internal location id", "location id"],
  businessName: ["business name", "name"],
  phone: ["phone", "phone number"],
  address: ["address"],
  hours: ["business hours", "hours"],
  lat: ["latitude", "lat"],
  lng: ["longitude", "lng", "long"],
};

function mapRow(row, aliasMap) {
  const lowerRow = {};
  Object.keys(row).forEach(k => { lowerRow[k.trim().toLowerCase()] = row[k]; });
  const out = {};
  Object.entries(aliasMap).forEach(([field, aliases]) => {
    for (const a of aliases) {
      if (lowerRow[a] !== undefined && lowerRow[a] !== "") { out[field] = String(lowerRow[a]).trim(); return; }
    }
    out[field] = "";
  });
  return out;
}

function parseUploadedFile(file, onData, onError) {
  const isCSV = /\.csv$/i.test(file.name);
  const reader = new FileReader();
  if (isCSV) {
    reader.onload = (e) => {
      const result = Papa.parse(e.target.result, { header: true, skipEmptyLines: true });
      onData(result.data);
    };
    reader.onerror = () => onError("Could not read the file.");
    reader.readAsText(file);
  } else {
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(e.target.result, { type: "binary" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json(sheet, { defval: "" });
        onData(json);
      } catch (err) { onError("Could not parse this Excel file. Try exporting as CSV."); }
    };
    reader.onerror = () => onError("Could not read the file.");
    reader.readAsBinaryString(file);
  }
}

function downloadCSV(filename, rows) {
  const safeRows = rows && rows.length ? rows : [{ "No data": "" }];
  const headers = Object.keys(safeRows[0]);
  const esc = (v) => {
    let s = v == null ? "" : String(v);
    if (/[",\n]/.test(s)) s = `"${s.replace(/"/g, '""')}"`;
    return s;
  };
  const csv = [headers.join(","), ...safeRows.map(r => headers.map(h => esc(r[h])).join(","))].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; document.body.appendChild(a); a.click();
  document.body.removeChild(a); URL.revokeObjectURL(url);
}

/* --------------------------- VERIFICATION ENGINE ---------------------------- */

function processExpectedChange(change, provider, settings) {
  const gbpLocations = provider.getLocations();
  const match = matchLocation(change, gbpLocations);
  const now = new Date();
  const base = {
    id: nextId("rec"),
    changeId: change.id,
    client: change.clientName || "Unknown Client",
    branch: change.branchName || "-",
    locationId: change.locationId || "-",
    changeType: change.changeType,
    oldValue: change.oldValue,
    expectedValue: change.expectedNewValue,
    priority: change.priority || "Normal",
    requestDate: change.requestDate || now.toISOString().slice(0, 10),
    requestedBy: change.requestedBy || "-",
    matchMethod: match.method,
    matchConfidence: match.confidence,
    matchedLocationId: match.location ? match.location.gbpLocationId : null,
    createdAt: now,
    attempts: 0,
    currentGbpValue: null,
    unexpectedChange: null,
    nextCheckDemoAt: null,
    source: provider.sourceLabel,
    reviewed: false,
    notes: [],
    isDemo: false,
    checks: [{ n: 0, time: now, event: "Change request created" }],
  };

  if (!match.location || match.confidence === "low") {
    return { ...base, status: "GRAY" };
  }

  const fieldKey = FIELD_KEY[change.changeType];
  const normalizer = NORMALIZER[change.changeType];
  const currentVal = match.location[fieldKey];
  const isVerified = normalizer(currentVal) === normalizer(change.expectedNewValue) && normalizer(currentVal) !== "";

  let unexpectedChange = null;
  if (change.changeType !== "Business Name" && change.branchName) {
    const sim = similarity(normalizeName(change.branchName), normalizeName(match.location.businessName));
    if (sim < 0.55) {
      unexpectedChange = { field: "Business Name", from: change.branchName, to: match.location.businessName };
    }
  }

  const checks = [...base.checks, {
    n: 1, time: now, gbpValue: currentVal, result: isVerified ? "VERIFIED" : "PENDING",
  }];

  if (isVerified) {
    return { ...base, currentGbpValue: currentVal, attempts: 1, checks, status: "GREEN", verifiedAt: now, unexpectedChange };
  }
  return {
    ...base, currentGbpValue: currentVal, attempts: 1, checks, status: "YELLOW", unexpectedChange,
    nextCheckDemoAt: Date.now() + DEMO_SECONDS[0] * 1000,
  };
}

function advanceCheck(record, provider, settings) {
  const loc = provider.getLocation(record.matchedLocationId);
  const fieldKey = FIELD_KEY[record.changeType];
  const normalizer = NORMALIZER[record.changeType];
  const currentVal = loc ? loc[fieldKey] : record.currentGbpValue;
  const attempts = record.attempts + 1;
  const isVerified = normalizer(currentVal) === normalizer(record.expectedValue) && normalizer(currentVal) !== "";
  const now = new Date();
  const result = isVerified ? "VERIFIED" : (attempts >= settings.maxAttempts ? "EXCEPTION" : "PENDING");
  const checks = [...record.checks, { n: attempts, time: now, gbpValue: currentVal, result }];

  let status = record.status, nextCheckDemoAt = null, verifiedAt = record.verifiedAt;
  if (isVerified) { status = "GREEN"; verifiedAt = now; }
  else if (attempts >= settings.maxAttempts) { status = "RED"; }
  else {
    status = "YELLOW";
    const idx = Math.min(attempts, DEMO_SECONDS.length - 1);
    nextCheckDemoAt = Date.now() + DEMO_SECONDS[idx] * 1000;
  }
  return { ...record, attempts, checks, currentGbpValue: currentVal, status, nextCheckDemoAt, verifiedAt };
}

/* -------------------------------- APP -------------------------------------- */

const NAV = [
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { key: "today", label: "Today's Verification", icon: Sun },
  { key: "expected", label: "Expected Changes", icon: FileText },
  { key: "gbpdata", label: "GBP Data", icon: Database },
  { key: "exceptions", label: "Exceptions", icon: AlertTriangle },
  { key: "clients", label: "Clients", icon: Users },
  { key: "insights", label: "Insights", icon: TrendingUp },
  { key: "audit", label: "Audit Log", icon: ScrollText },
  { key: "settings", label: "Settings", icon: SettingsIcon },
  { key: "help", label: "Help", icon: HelpCircle },
];

export default function App() {
  const [gbpLocations, setGbpLocations] = useState(() => buildDemoGbpLocations());
  const [expectedChanges, setExpectedChanges] = useState(() => buildDemoUnprocessedChanges(buildDemoGbpLocations()));
  const [records, setRecords] = useState(() => {
    const locs = gbpLocations;
    return buildDemoRecords(locs);
  });
  const [auditLog, setAuditLog] = useState(() => seedAuditFromRecords(records));
  const [settings, setSettings] = useState({
    intervalsMinutes: DEFAULT_INTERVALS_MIN, maxAttempts: 4, demoAutoCheck: true, currentUser: "R. Menon",
  });
  const [page, setPage] = useState("dashboard");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [selectedRecordId, setSelectedRecordId] = useState(null);
  const [filters, setFilters] = useState({ client: "All", changeType: "All", status: "All", priority: "All", q: "" });
  const [toast, setToast] = useState(null);
  const [selectedClient, setSelectedClient] = useState("ICL Fincorp");

  const gbpRef = useRef(gbpLocations);
  const settingsRef = useRef(settings);
  useEffect(() => { gbpRef.current = gbpLocations; }, [gbpLocations]);
  useEffect(() => { settingsRef.current = settings; }, [settings]);
  const provider = useMemo(() => new FileUploadGBPProvider(gbpLocations), [gbpLocations]);

  function pushAudit(entries) {
    setAuditLog(prev => [...entries, ...prev]);
  }

  function showToast(msg, tone = "default") {
    setToast({ msg, tone, id: nextId("t") });
    setTimeout(() => setToast(t => (t && t.msg === msg ? null : t)), 3200);
  }

  // Live demo recheck clock — only runs while this tab is open.
  useEffect(() => {
    const timer = setInterval(() => {
      if (!settingsRef.current.demoAutoCheck) return;
      const now = Date.now();
      const liveProvider = new FileUploadGBPProvider(gbpRef.current);
      let audits = [];
      setRecords(prev => prev.map(r => {
        if (r.status !== "YELLOW" || !r.nextCheckDemoAt || now < r.nextCheckDemoAt) return r;
        const updated = advanceCheck(r, liveProvider, settingsRef.current);
        audits.push(auditEntryFor(updated, settingsRef.current, "Automatic recheck (simulated)"));
        return updated;
      }));
      if (audits.length) pushAudit(audits);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  function auditEntryFor(record, settingsSnapshot, actionTaken) {
    const lastCheck = record.checks[record.checks.length - 1];
    return {
      id: nextId("aud"), timestamp: new Date(), user: settingsSnapshot.currentUser,
      client: record.client, location: record.branch, changeType: record.changeType,
      expectedValue: record.expectedValue, gbpValue: record.currentGbpValue,
      result: record.status, attemptNumber: record.attempts, source: record.source,
      actionTaken, notes: lastCheck && lastCheck.event ? lastCheck.event : "",
    };
  }

  function runVerification() {
    const unprocessed = expectedChanges.filter(c => !records.some(r => r.changeId === c.id));
    if (unprocessed.length === 0) {
      showToast("No new expected changes to process — upload a file or add rows first.");
      return;
    }
    const newRecords = unprocessed.map(c => processExpectedChange(c, provider, settings));
    setRecords(prev => [...newRecords, ...prev]);
    pushAudit(newRecords.map(r => auditEntryFor(r, settings, "Verification run")));
    showToast(`Run complete — processed ${newRecords.length} expected change${newRecords.length > 1 ? "s" : ""}.`, "success");
  }

  function retryVerification(recordId) {
    setRecords(prev => prev.map(r => {
      if (r.id !== recordId) return r;
      const updated = advanceCheck({ ...r, status: "YELLOW" }, provider, settings);
      pushAudit([auditEntryFor(updated, settings, "Manual retry")]);
      return updated;
    }));
    showToast("Retry check complete.");
  }

  function markReviewed(recordId) {
    setRecords(prev => prev.map(r => r.id === recordId ? { ...r, reviewed: true } : r));
    const r = records.find(x => x.id === recordId);
    if (r) pushAudit([auditEntryFor(r, settings, "Marked as reviewed")]);
    showToast("Marked as reviewed.");
  }

  function addNote(recordId, text) {
    if (!text.trim()) return;
    setRecords(prev => prev.map(r => r.id === recordId
      ? { ...r, notes: [...(r.notes || []), { time: new Date(), text, author: settings.currentUser }] }
      : r));
    const r = records.find(x => x.id === recordId);
    if (r) pushAudit([{ ...auditEntryFor(r, settings, "Note added"), notes: text }]);
  }

  function assignRecord(recordId, assignee) {
    setRecords(prev => prev.map(r => r.id === recordId ? { ...r, assignedTo: assignee } : r));
    showToast(`Assigned to ${assignee}.`);
  }

  // ---- uploads ----
  function handleExpectedUpload(file) {
    parseUploadedFile(file, (rows) => {
      const mapped = rows.map(r => mapRow(r, EXPECTED_ALIASES)).filter(r => r.changeType);
      if (!mapped.length) { showToast("No valid rows found. Check your column headers.", "error"); return; }
      const withIds = mapped.map(r => ({ ...r, id: nextId("chg") }));
      setExpectedChanges(prev => [...prev, ...withIds]);
      showToast(`Imported ${withIds.length} expected change row(s). Click "Run Verification" to process.`, "success");
    }, (err) => showToast(err, "error"));
  }
  function handleGbpUpload(file) {
    parseUploadedFile(file, (rows) => {
      const mapped = rows.map(r => mapRow(r, GBP_ALIASES)).filter(r => r.businessName || r.gbpLocationId);
      if (!mapped.length) { showToast("No valid rows found. Check your column headers.", "error"); return; }
      setGbpLocations(prev => {
        const byId = new Map(prev.map(l => [l.gbpLocationId, l]));
        mapped.forEach(m => { if (m.gbpLocationId) byId.set(m.gbpLocationId, { ...byId.get(m.gbpLocationId), ...m }); });
        const merged = [...byId.values(), ...mapped.filter(m => !m.gbpLocationId)];
        return merged;
      });
      showToast(`Imported ${mapped.length} GBP location row(s).`, "success");
    }, (err) => showToast(err, "error"));
  }

  function simulateGoogleUpdate(recordId) {
    const r = records.find(x => x.id === recordId);
    if (!r || !r.matchedLocationId) return;
    setGbpLocations(gl => gl.map(l => l.gbpLocationId === r.matchedLocationId
      ? { ...l, [FIELD_KEY[r.changeType]]: r.expectedValue }
      : l));
    showToast("Demo only: pushed the expected value into the GBP snapshot so you can watch the next check verify it.");
  }

  const clients = useMemo(() => Array.from(new Set(records.map(r => r.client))), [records]);

  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      if (filters.client !== "All" && r.client !== filters.client) return false;
      if (filters.changeType !== "All" && r.changeType !== filters.changeType) return false;
      if (filters.status !== "All" && r.status !== filters.status) return false;
      if (filters.priority !== "All" && r.priority !== filters.priority) return false;
      if (filters.q) {
        const q = filters.q.toLowerCase();
        const hay = `${r.client} ${r.branch} ${r.locationId} ${r.changeType} ${r.oldValue} ${r.expectedValue}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [records, filters]);

  const counts = useMemo(() => ({
    total: filteredRecords.length,
    green: filteredRecords.filter(r => r.status === "GREEN").length,
    yellow: filteredRecords.filter(r => r.status === "YELLOW").length,
    red: filteredRecords.filter(r => r.status === "RED").length,
    gray: filteredRecords.filter(r => r.status === "GRAY").length,
  }), [filteredRecords]);

  const selectedRecord = records.find(r => r.id === selectedRecordId) || null;

  function goDetail(id) { setSelectedRecordId(id); setPage("detail"); }

  return (
    <div style={{ fontFamily: "'Inter', ui-sans-serif, system-ui, -apple-system, sans-serif" }} className="min-h-screen w-full bg-slate-50 text-slate-900 flex">
      {/* -------------------------------- SIDEBAR -------------------------------- */}
      {mobileNavOpen && (
        <div className="fixed inset-0 bg-black/30 z-40 lg:hidden" onClick={() => setMobileNavOpen(false)} />
      )}
      <aside className={`flex flex-col w-60 shrink-0 bg-white border-r border-slate-200 py-5 px-3 overflow-y-auto
        fixed inset-y-0 left-0 z-50 h-screen transition-transform duration-200
        ${mobileNavOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 lg:sticky lg:top-0`}>
        <div className="px-2 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-sm">GV</div>
            <div>
              <div className="font-semibold text-[13.5px] leading-tight text-slate-900">GBP Change</div>
              <div className="text-[11px] text-slate-500 leading-tight">Verification &amp; Monitoring</div>
            </div>
          </div>
          <button onClick={() => setMobileNavOpen(false)} className="lg:hidden p-1 text-slate-400 hover:text-slate-700">
            <X size={18} />
          </button>
        </div>
        <nav className="flex-1 space-y-0.5">
          {NAV.map(item => {
            const Icon = item.icon;
            const active = page === item.key || (page === "detail" && item.key === "dashboard");
            return (
              <button key={item.key} onClick={() => { setPage(item.key); setMobileNavOpen(false); }}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-[13px] font-medium transition-colors ${active ? "bg-indigo-50 text-indigo-700" : "text-slate-600 hover:bg-slate-100"}`}>
                <Icon size={16} strokeWidth={2} />
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="mt-4 mx-1 p-3 rounded-lg bg-slate-50 border border-slate-200 text-[11px] text-slate-500 leading-snug">
          Complements the SI <b>Out of Sync</b> feature. This tool verifies requested GBP changes and monitors for exceptions — it does not sync data.
        </div>
      </aside>

      {/* -------------------------------- MAIN -------------------------------- */}
      <div className="flex-1 min-w-0 flex flex-col">
        <TopBar
          onRun={runVerification}
          onMenu={() => setMobileNavOpen(true)}
          currentPageLabel={(NAV.find(n => n.key === page) || {}).label || "GBP Change Verification"}
          pendingCount={expectedChanges.filter(c => !records.some(r => r.changeId === c.id)).length}
          onExport={() => downloadCSV("full_verification_report.csv", records.map(exportRow))}
          filters={filters} setFilters={setFilters} clients={clients}
        />
        {toast && (
          <div className={`mx-4 mt-3 md:mx-6 px-4 py-2.5 rounded-lg text-[13px] border flex items-center gap-2 ${toast.tone === "success" ? "bg-emerald-50 border-emerald-200 text-emerald-800" : toast.tone === "error" ? "bg-red-50 border-red-200 text-red-800" : "bg-indigo-50 border-indigo-200 text-indigo-800"}`}>
            <Info size={14} /> {toast.msg}
          </div>
        )}

        <main className="flex-1 p-4 md:p-6 max-w-[1400px] w-full mx-auto">
          {page === "dashboard" && (
            <Dashboard counts={counts} records={filteredRecords} onView={goDetail} onExport={downloadCSV} />
          )}
          {page === "today" && (
            <TodayView records={records} onView={goDetail} clients={clients} />
          )}
          {page === "expected" && (
            <ExpectedChangesPage
              expectedChanges={expectedChanges} records={records}
              onUpload={handleExpectedUpload} onRun={runVerification}
            />
          )}
          {page === "gbpdata" && (
            <GbpDataPage gbpLocations={gbpLocations} onUpload={handleGbpUpload} />
          )}
          {page === "exceptions" && (
            <ExceptionsPage records={records} onView={goDetail} onReview={markReviewed} onRetry={retryVerification} onExport={downloadCSV} />
          )}
          {page === "clients" && (
            <ClientsPage records={records} clients={clients} selectedClient={selectedClient} setSelectedClient={setSelectedClient} />
          )}
          {page === "insights" && (
            <InsightsPage records={records} />
          )}
          {page === "audit" && (
            <AuditLogPage auditLog={auditLog} onExport={downloadCSV} />
          )}
          {page === "settings" && (
            <SettingsPage settings={settings} setSettings={setSettings} />
          )}
          {page === "help" && <HelpPage />}
          {page === "detail" && selectedRecord && (
            <DetailPage
              record={selectedRecord} onBack={() => setPage("dashboard")}
              onRetry={retryVerification} onReview={markReviewed} onNote={addNote}
              onAssign={assignRecord} onSimulateGoogleUpdate={simulateGoogleUpdate}
              settings={settings}
            />
          )}
        </main>
      </div>
    </div>
  );
}

function seedAuditFromRecords(records) {
  const entries = [];
  records.forEach(r => {
    r.checks.forEach(c => {
      entries.push({
        id: nextId("aud"), timestamp: c.time, user: "System", client: r.client, location: r.branch,
        changeType: r.changeType, expectedValue: r.expectedValue, gbpValue: c.gbpValue ?? "-",
        result: c.result || "CREATED", attemptNumber: c.n, source: r.source,
        actionTaken: c.n === 0 ? "Verification record created" : "Automatic check",
        notes: c.event || "",
      });
    });
  });
  return entries.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
}

function exportRow(r) {
  return {
    Client: r.client, Branch: r.branch, "Location ID": r.locationId, "Change Type": r.changeType,
    "Old Value": r.oldValue, "Expected Value": r.expectedValue, "Current GBP Value": r.currentGbpValue ?? "-",
    Status: `${r.status} — ${STATUS_META[r.status].label}`, "Last Checked": fmtDateTime(r.checks[r.checks.length - 1]?.time),
    "Attempt Count": r.attempts, "Match Method": r.matchMethod, Priority: r.priority, "Requested By": r.requestedBy,
  };
}

/* ------------------------------- COMPONENTS -------------------------------- */

function StatusBadge({ status, size = "md" }) {
  const m = STATUS_META[status];
  const Icon = m.icon;
  const padding = size === "sm" ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-[12px]";
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full font-semibold border ${padding}`}
      style={{ background: m.bg, color: m.text, borderColor: m.border }}>
      <Icon size={size === "sm" ? 11 : 13} />
      {status} — {m.label}
    </span>
  );
}

function PriorityChip({ p }) {
  const map = { Urgent: "bg-red-100 text-red-700", High: "bg-orange-100 text-orange-700", Normal: "bg-slate-100 text-slate-600", Low: "bg-slate-50 text-slate-400" };
  return <span className={`text-[11px] font-medium px-1.5 py-0.5 rounded ${map[p] || map.Normal}`}>{p}</span>;
}

function TopBar({ onRun, onMenu, currentPageLabel, pendingCount, onExport, filters, setFilters, clients }) {
  return (
    <div className="sticky top-0 z-20 bg-white/90 backdrop-blur border-b border-slate-200">
      <div className="lg:hidden flex items-center gap-2 px-4 pt-3">
        <button onClick={onMenu} className="p-1.5 -ml-1.5 rounded-md text-slate-500 hover:bg-slate-100">
          <Menu size={18} />
        </button>
        <span className="text-[13px] font-semibold text-slate-800">{currentPageLabel}</span>
      </div>
      <div className="px-4 md:px-6 py-3 flex flex-wrap items-center gap-2 max-w-[1400px] mx-auto w-full">
        <div className="relative flex-1 min-w-[180px] max-w-xs">
          <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={filters.q} onChange={e => setFilters(f => ({ ...f, q: e.target.value }))}
            placeholder="Search client, branch, value…"
            className="w-full pl-8 pr-3 py-1.5 text-[13px] rounded-md border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400" />
        </div>
        <FilterSelect label="Client" value={filters.client} onChange={v => setFilters(f => ({ ...f, client: v }))} options={["All", ...clients]} />
        <FilterSelect label="Change type" value={filters.changeType} onChange={v => setFilters(f => ({ ...f, changeType: v }))} options={["All", ...CHANGE_TYPES]} />
        <FilterSelect label="Status" value={filters.status} onChange={v => setFilters(f => ({ ...f, status: v }))} options={["All", "GREEN", "YELLOW", "RED", "GRAY"]} />
        <FilterSelect label="Priority" value={filters.priority} onChange={v => setFilters(f => ({ ...f, priority: v }))} options={["All", ...PRIORITIES]} />
        <div className="flex-1" />
        <button onClick={onExport} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[13px] font-medium border border-slate-200 text-slate-600 hover:bg-slate-50">
          <Download size={14} /> Export
        </button>
        <button onClick={onRun} className="relative inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-[13px] font-semibold bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm">
          <Play size={14} /> Run Verification
          {pendingCount > 0 && <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-white text-[10px] font-bold w-5 h-5 min-w-[18px] px-1 rounded-full flex items-center justify-center">{pendingCount}</span>}
        </button>
      </div>
    </div>
  );
}

function FilterSelect({ label, value, onChange, options }) {
  return (
    <select value={value} onChange={e => onChange(e.target.value)}
      title={label}
      className="text-[12.5px] px-2 py-1.5 rounded-md border border-slate-200 bg-white text-slate-600 focus:outline-none focus:ring-2 focus:ring-indigo-200 max-w-[140px]">
      {options.map(o => <option key={o} value={o}>{o === "All" ? `${label}: All` : o}</option>)}
    </select>
  );
}

function SummaryCards({ counts }) {
  const cards = [
    { label: "Total Changes", value: counts.total, tone: "slate" },
    { label: "Verified", value: counts.green, tone: "GREEN" },
    { label: "Pending", value: counts.yellow, tone: "YELLOW" },
    { label: "Exceptions", value: counts.red, tone: "RED" },
    { label: "Matching Required", value: counts.gray, tone: "GRAY" },
  ];
  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-5">
      {cards.map(c => {
        const meta = STATUS_META[c.tone];
        return (
          <div key={c.label} className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="text-[12px] text-slate-500 font-medium mb-1.5">{c.label}</div>
            <div className="text-2xl font-bold" style={{ color: meta ? meta.text : "#0F172A" }}>{c.value}</div>
          </div>
        );
      })}
    </div>
  );
}

function RecordsTable({ records, onView, compact }) {
  if (!records.length) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-10 text-center text-slate-400 text-[13px]">
        No records match the current filters.
      </div>
    );
  }
  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-[12.5px]">
          <thead>
            <tr className="bg-slate-50 text-slate-500 text-left border-b border-slate-200">
              {["Client", "Branch", "Location ID", "Change Type", "Old Value", "Expected", "Current GBP", "Status", "Last Checked", "Next Check", "Attempts", "Match Method", ""].map(h => (
                <th key={h} className="px-3 py-2 font-semibold whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {records.map(r => {
              const last = r.checks[r.checks.length - 1];
              return (
                <tr key={r.id} className="border-b border-slate-100 hover:bg-slate-50/70 transition-colors">
                  <td className="px-3 py-2 whitespace-nowrap font-medium text-slate-700">{r.client}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{r.branch}</td>
                  <td className="px-3 py-2 whitespace-nowrap font-mono text-[11.5px] text-slate-500">{r.locationId}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{r.changeType}</td>
                  <td className="px-3 py-2 whitespace-nowrap text-slate-500 max-w-[120px] truncate">{r.oldValue}</td>
                  <td className="px-3 py-2 whitespace-nowrap max-w-[120px] truncate">{r.expectedValue}</td>
                  <td className="px-3 py-2 whitespace-nowrap max-w-[120px] truncate">{r.currentGbpValue ?? "Waiting for GBP data"}</td>
                  <td className="px-3 py-2 whitespace-nowrap"><StatusBadge status={r.status} size="sm" /></td>
                  <td className="px-3 py-2 whitespace-nowrap text-slate-500">{fmtDateTime(last?.time)}</td>
                  <td className="px-3 py-2 whitespace-nowrap text-slate-400">{r.status === "YELLOW" ? "Scheduled (simulated)" : "-"}</td>
                  <td className="px-3 py-2 whitespace-nowrap text-center">{r.attempts}</td>
                  <td className="px-3 py-2 whitespace-nowrap text-slate-500">{r.matchMethod}</td>
                  <td className="px-3 py-2 whitespace-nowrap">
                    <button onClick={() => onView(r.id)} className="text-indigo-600 hover:text-indigo-800 font-medium text-[12px]">
                      {r.status === "RED" ? "Investigate" : "View"} <ChevronRight size={12} className="inline" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* --------------------------------- PAGES ------------------------------------ */

function Dashboard({ counts, records, onView, onExport }) {
  return (
    <div>
      <PageHeader title="Dashboard" subtitle="Every expected GBP change, matched against the live GBP snapshot and classified automatically." />
      <SummaryCards counts={counts} />
      <div className="flex items-center justify-between mb-3">
        <div className="text-[13px] font-semibold text-slate-700">All verification records</div>
        <button onClick={() => onExport("full_verification_report.csv", records.map(exportRow))} className="text-[12px] text-indigo-600 font-medium flex items-center gap-1">
          <Download size={13} /> Export view
        </button>
      </div>
      <RecordsTable records={records} onView={onView} />
    </div>
  );
}

function TodayView({ records, onView, clients }) {
  const todayStr = new Date().toDateString();
  const isToday = (d) => d && new Date(d).toDateString() === todayStr;
  const todays = records.filter(r => isToday(r.createdAt));
  const yestPending = records.filter(r => !isToday(r.createdAt) && r.status === "YELLOW");
  const prevExceptions = records.filter(r => !isToday(r.createdAt) && r.status === "RED" && !r.reviewed);
  const awaitingReview = records.filter(r => r.status === "GRAY");

  return (
    <div>
      <PageHeader title="Today's Verification" subtitle="A rolling view of everything created or checked today, plus anything carried over that still needs attention." />
      {clients.map(client => {
        const rows = todays.filter(r => r.client === client);
        if (!rows.length) return null;
        const v = rows.filter(r => r.status === "GREEN").length;
        const p = rows.filter(r => r.status === "YELLOW").length;
        const e = rows.filter(r => r.status === "RED").length;
        return (
          <div key={client} className="bg-white rounded-xl border border-slate-200 p-4 mb-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-[11px] text-slate-400 font-medium uppercase tracking-wide">Client</div>
                <div className="text-[15px] font-semibold">{client}</div>
              </div>
              <div className="flex gap-4 text-[12.5px]">
                <span className="text-slate-500">Today's changes: <b className="text-slate-800">{rows.length}</b></span>
                <span className="text-emerald-600 font-medium">{v} Verified</span>
                <span className="text-amber-600 font-medium">{p} Pending</span>
                <span className="text-red-600 font-medium">{e} Exceptions</span>
              </div>
            </div>
            <div className="divide-y divide-slate-100">
              {rows.map(r => (
                <button key={r.id} onClick={() => onView(r.id)} className="w-full flex items-center justify-between py-2 text-left hover:bg-slate-50 px-1.5 -mx-1.5 rounded">
                  <div className="text-[13px]">
                    <span className="font-medium text-slate-700">{r.branch}</span>
                    <span className="text-slate-400"> · {r.changeType} · </span>
                    <span className="text-slate-500">{fmtDateTime(r.createdAt)}</span>
                  </div>
                  <StatusBadge status={r.status} size="sm" />
                </button>
              ))}
            </div>
          </div>
        );
      })}
      {!records.some(r => isToday(r.createdAt)) && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 text-slate-400 text-[13px] mb-4">No verification activity recorded yet today.</div>
      )}

      <div className="grid md:grid-cols-3 gap-4 mt-2">
        <CarryoverCard title="Yesterday's Pending" icon={Clock} tone="YELLOW" rows={yestPending} onView={onView} />
        <CarryoverCard title="Previous Exceptions" icon={AlertTriangle} tone="RED" rows={prevExceptions} onView={onView} />
        <CarryoverCard title="Awaiting Manual Match" icon={CircleHelp} tone="GRAY" rows={awaitingReview} onView={onView} />
      </div>
    </div>
  );
}

function CarryoverCard({ title, icon: Icon, tone, rows, onView }) {
  const meta = STATUS_META[tone];
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4">
      <div className="flex items-center gap-2 mb-3">
        <Icon size={14} style={{ color: meta.text }} />
        <div className="text-[13px] font-semibold text-slate-700">{title}</div>
        <span className="ml-auto text-[11px] font-semibold px-1.5 py-0.5 rounded" style={{ background: meta.bg, color: meta.text }}>{rows.length}</span>
      </div>
      {rows.length === 0 ? (
        <div className="text-[12px] text-slate-400">Nothing here.</div>
      ) : (
        <div className="space-y-1.5">
          {rows.slice(0, 5).map(r => (
            <button key={r.id} onClick={() => onView(r.id)} className="w-full text-left text-[12px] text-slate-600 hover:text-indigo-600 truncate block">
              {r.branch} — {r.changeType}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function PageHeader({ title, subtitle, right }) {
  return (
    <div className="flex items-start justify-between mb-5 gap-4 flex-wrap">
      <div>
        <h1 className="text-[19px] font-bold text-slate-900">{title}</h1>
        {subtitle && <p className="text-[13px] text-slate-500 mt-0.5 max-w-2xl">{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

function UploadBox({ label, hint, onFile, templateRows, templateName }) {
  const inputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
      onDragLeave={() => setDragOver(false)}
      onDrop={(e) => { e.preventDefault(); setDragOver(false); const f = e.dataTransfer.files?.[0]; if (f) onFile(f); }}
      className={`rounded-xl border-2 border-dashed p-6 text-center transition-colors ${dragOver ? "border-indigo-400 bg-indigo-50/50" : "border-slate-200 bg-white"}`}>
      <UploadCloud size={26} className="mx-auto text-indigo-500 mb-2" />
      <div className="text-[13.5px] font-semibold text-slate-700">{label}</div>
      <div className="text-[12px] text-slate-500 mt-1 mb-3 max-w-sm mx-auto">{hint}</div>
      <div className="flex items-center justify-center gap-2">
        <button onClick={() => inputRef.current?.click()} className="px-3.5 py-1.5 rounded-md bg-indigo-600 text-white text-[12.5px] font-semibold hover:bg-indigo-700">
          Choose file
        </button>
        {templateRows && (
          <button onClick={() => downloadCSV(templateName, templateRows)} className="px-3.5 py-1.5 rounded-md border border-slate-200 text-slate-600 text-[12.5px] font-medium hover:bg-slate-50">
            Download template
          </button>
        )}
      </div>
      <input ref={inputRef} type="file" accept=".csv,.xlsx,.xls" className="hidden"
        onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); e.target.value = ""; }} />
      <div className="text-[11px] text-slate-400 mt-2">Accepts .csv, .xlsx, .xls — or drag a file here</div>
    </div>
  );
}

function ExpectedChangesPage({ expectedChanges, records, onUpload, onRun }) {
  const unprocessed = expectedChanges.filter(c => !records.some(r => r.changeId === c.id));
  const template = [{
    "Client Name": "ICL Fincorp", "Location ID": "ICL-KL-KOC-001", "Store Code": "ICL-KL-KOC-001",
    "Branch Name": "Kochi", "GBP Location ID": "GBP-ICL-KOC", "Change Type": "Phone",
    "Old Value": "9876543200", "Expected New Value": "9876543210", "Request Date": "2026-07-31",
    "Requested By": "R. Menon", "Priority": "Normal",
  }];
  return (
    <div>
      <PageHeader title="Expected Changes" subtitle="Upload the changes requested through SI / V1 / V3. Each row becomes a verification record once you run verification." />
      <UploadBox label="Upload expected changes" hint="Excel or CSV export from SI, V1, V3, or a manually built list of requested GBP changes." onFile={onUpload} templateRows={template} templateName="expected_changes_template.csv" />

      <div className="flex items-center justify-between mt-6 mb-3">
        <div className="text-[13px] font-semibold text-slate-700">Uploaded rows ({expectedChanges.length})</div>
        <button onClick={onRun} disabled={!unprocessed.length}
          className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-md text-[13px] font-semibold ${unprocessed.length ? "bg-indigo-600 text-white hover:bg-indigo-700" : "bg-slate-100 text-slate-400 cursor-not-allowed"}`}>
          <Play size={14} /> Run Verification {unprocessed.length ? `(${unprocessed.length} pending)` : ""}
        </button>
      </div>
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-[12.5px]">
            <thead>
              <tr className="bg-slate-50 text-slate-500 text-left border-b border-slate-200">
                {["Client", "Branch", "Store Code", "GBP Location ID", "Change Type", "Old Value", "Expected", "Priority", "Requested", "Processed?"].map(h => <th key={h} className="px-3 py-2 font-semibold whitespace-nowrap">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {expectedChanges.map(c => {
                const processed = records.some(r => r.changeId === c.id);
                return (
                  <tr key={c.id} className="border-b border-slate-100">
                    <td className="px-3 py-2 whitespace-nowrap font-medium">{c.clientName}</td>
                    <td className="px-3 py-2 whitespace-nowrap">{c.branchName}</td>
                    <td className="px-3 py-2 whitespace-nowrap font-mono text-[11.5px] text-slate-500">{c.storeCode}</td>
                    <td className="px-3 py-2 whitespace-nowrap font-mono text-[11.5px] text-slate-500">{c.gbpLocationId || "-"}</td>
                    <td className="px-3 py-2 whitespace-nowrap">{c.changeType}</td>
                    <td className="px-3 py-2 whitespace-nowrap text-slate-500">{c.oldValue}</td>
                    <td className="px-3 py-2 whitespace-nowrap">{c.expectedNewValue}</td>
                    <td className="px-3 py-2 whitespace-nowrap"><PriorityChip p={c.priority || "Normal"} /></td>
                    <td className="px-3 py-2 whitespace-nowrap text-slate-500">{c.requestDate}</td>
                    <td className="px-3 py-2 whitespace-nowrap">
                      {processed ? <span className="text-emerald-600 text-[11.5px] font-medium">Processed</span> : <span className="text-amber-600 text-[11.5px] font-medium">Awaiting run</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function GbpDataPage({ gbpLocations, onUpload }) {
  const template = [{
    "Business Name": "ICL Fincorp - Kochi", "Store Code": "ICL-KL-KOC-001", "GBP Location ID": "GBP-ICL-KOC",
    "Internal Location ID": "ICL-KOC-001", "Phone": "9876543210", "Address": "101, MG Road, Kochi",
    "Business Hours": "Mon-Sat 9:30 AM-6:30 PM, Sun Closed", "Latitude": "9.93", "Longitude": "76.26",
  }];
  return (
    <div>
      <PageHeader title="GBP Data" subtitle="This is the current-state snapshot the comparison engine checks against. In the MVP it comes from a file export; the same interface can later be backed by the Google Business Profile API." />
      <div className="mb-5 p-3.5 rounded-lg bg-indigo-50 border border-indigo-100 text-[12.5px] text-indigo-800 flex gap-2">
        <Info size={15} className="shrink-0 mt-0.5" />
        <div>
          <b>Data provider:</b> File Upload Provider (active). A future <code className="bg-white/60 px-1 rounded">GoogleBusinessProfileAPIProvider</code> can replace this without changing matching, comparison, or the dashboard — see Settings.
        </div>
      </div>
      <UploadBox label="Upload GBP data" hint="A Google Business Profile export, or an equivalent snapshot of current listing values, per location." onFile={onUpload} templateRows={template} templateName="gbp_data_template.csv" />

      <div className="flex items-center justify-between mt-6 mb-3">
        <div className="text-[13px] font-semibold text-slate-700">Current GBP snapshot ({gbpLocations.length} locations)</div>
      </div>
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto max-h-[520px] overflow-y-auto">
          <table className="w-full text-[12.5px]">
            <thead className="sticky top-0 bg-slate-50">
              <tr className="text-slate-500 text-left border-b border-slate-200">
                {["Business Name", "Store Code", "GBP Location ID", "Phone", "Address", "Business Hours"].map(h => <th key={h} className="px-3 py-2 font-semibold whitespace-nowrap bg-slate-50">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {gbpLocations.map(l => (
                <tr key={l.gbpLocationId} className="border-b border-slate-100">
                  <td className="px-3 py-2 whitespace-nowrap font-medium">{l.businessName}</td>
                  <td className="px-3 py-2 whitespace-nowrap font-mono text-[11.5px] text-slate-500">{l.storeCode}</td>
                  <td className="px-3 py-2 whitespace-nowrap font-mono text-[11.5px] text-slate-500">{l.gbpLocationId}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{l.phone}</td>
                  <td className="px-3 py-2 whitespace-nowrap max-w-[220px] truncate">{l.address}</td>
                  <td className="px-3 py-2 whitespace-nowrap max-w-[220px] truncate">{l.hours}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function ExceptionsPage({ records, onView, onReview, onRetry, onExport }) {
  const exceptions = records.filter(r => r.status === "RED");
  const outstanding = exceptions.filter(r => !r.reviewed);
  const reviewed = exceptions.filter(r => r.reviewed);
  return (
    <div>
      <PageHeader title="Exceptions" subtitle="Requested changes that did not appear on Google after the maximum number of verification attempts. This is the only list Ops needs to work from."
        right={<button onClick={() => onExport("exceptions.csv", exceptions.map(exportRow))} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[12.5px] font-medium border border-slate-200 text-slate-600 hover:bg-slate-50"><Download size={13} /> Export exceptions</button>} />

      {exceptions.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-10 text-center text-slate-400 text-[13px]">No exceptions right now.</div>
      ) : (
        <>
          <div className="text-[12.5px] font-semibold text-slate-500 mb-2">Needs attention ({outstanding.length})</div>
          <div className="space-y-3 mb-6">
            {outstanding.map(r => <ExceptionCard key={r.id} r={r} onView={onView} onReview={onReview} onRetry={onRetry} />)}
          </div>
          {reviewed.length > 0 && (
            <>
              <div className="text-[12.5px] font-semibold text-slate-500 mb-2">Reviewed ({reviewed.length})</div>
              <div className="space-y-3 opacity-70">
                {reviewed.map(r => <ExceptionCard key={r.id} r={r} onView={onView} onReview={onReview} onRetry={onRetry} />)}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}

function ExceptionCard({ r, onView, onReview, onRetry }) {
  const first = r.checks.find(c => c.n === 1);
  const last = r.checks[r.checks.length - 1];
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <StatusBadge status="RED" size="sm" />
            {r.reviewed && <span className="text-[11px] text-slate-400 font-medium">Reviewed</span>}
          </div>
          <div className="text-[14.5px] font-semibold text-slate-800">{r.branch} Branch <span className="text-slate-400 font-normal">— {r.client}</span></div>
          <div className="text-[12.5px] text-slate-500 mt-1">Change: <b className="text-slate-700">{r.changeType}</b></div>
        </div>
        <div className="grid grid-cols-2 gap-x-8 gap-y-1 text-[12.5px] text-right">
          <div className="text-slate-400">Expected</div><div className="font-medium text-slate-700">{r.expectedValue}</div>
          <div className="text-slate-400">Current GBP</div><div className="font-medium text-slate-700">{r.currentGbpValue ?? "-"}</div>
          <div className="text-slate-400">Checks</div><div className="font-medium text-slate-700">{r.attempts}</div>
          <div className="text-slate-400">First check</div><div className="text-slate-600">{fmtDateTime(first?.time)}</div>
          <div className="text-slate-400">Last check</div><div className="text-slate-600">{fmtDateTime(last?.time)}</div>
        </div>
      </div>
      <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2">
        <div className="text-[12px] text-slate-500 max-w-md"><b className="text-slate-600">Recommended action:</b> Review GBP status and confirm whether the requested change was successfully submitted through SI.</div>
        <div className="flex gap-2 flex-wrap">
          {!r.reviewed && <button onClick={() => onReview(r.id)} className="px-2.5 py-1 rounded-md border border-slate-200 text-[12px] font-medium text-slate-600 hover:bg-slate-50">Mark as Reviewed</button>}
          <button onClick={() => onRetry(r.id)} className="px-2.5 py-1 rounded-md border border-slate-200 text-[12px] font-medium text-slate-600 hover:bg-slate-50">Retry Verification</button>
          <button onClick={() => onView(r.id)} className="px-2.5 py-1 rounded-md bg-indigo-600 text-white text-[12px] font-semibold hover:bg-indigo-700">Open</button>
        </div>
      </div>
    </div>
  );
}

function ClientsPage({ records, clients, selectedClient, setSelectedClient }) {
  const rows = records.filter(r => r.client === selectedClient);
  const total = rows.length;
  const verified = rows.filter(r => r.status === "GREEN").length;
  const pending = rows.filter(r => r.status === "YELLOW").length;
  const exceptions = rows.filter(r => r.status === "RED").length;
  const health = total ? Math.round((verified / total) * 100) : 0;

  const verifiedDurations = rows.filter(r => r.status === "GREEN" && r.verifiedAt).map(r => minutesBetween(new Date(r.createdAt), new Date(r.verifiedAt)));
  const avgMin = verifiedDurations.length ? Math.round(verifiedDurations.reduce((a, b) => a + b, 0) / verifiedDurations.length) : null;

  const breakdown = CHANGE_TYPES.map(ct => {
    const sub = rows.filter(r => r.changeType === ct);
    const v = sub.filter(r => r.status === "GREEN").length;
    return { ct, pct: sub.length ? Math.round((v / sub.length) * 100) : null, count: sub.length };
  });

  return (
    <div>
      <PageHeader title="Clients" subtitle="Per-client verification health, drawn from actual recorded verification data." />
      <div className="flex gap-2 mb-5 flex-wrap">
        {clients.map(c => (
          <button key={c} onClick={() => setSelectedClient(c)}
            className={`px-3 py-1.5 rounded-full text-[12.5px] font-medium border ${selectedClient === c ? "bg-indigo-600 text-white border-indigo-600" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"}`}>
            {c}
          </button>
        ))}
      </div>

      {total === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-10 text-center text-slate-400 text-[13px]">No verification records for this client yet.</div>
      ) : (
        <>
          <div className="grid md:grid-cols-2 gap-4 mb-5">
            <div className="bg-white rounded-xl border border-slate-200 p-5">
              <div className="text-[12px] text-slate-400 font-medium uppercase tracking-wide mb-1">Verification Health</div>
              <div className="text-3xl font-bold text-slate-900">{health}%</div>
              <div className="w-full h-2 rounded-full bg-slate-100 mt-3 overflow-hidden">
                <div className="h-full bg-emerald-500" style={{ width: `${health}%` }} />
              </div>
              <div className="grid grid-cols-4 gap-2 mt-4 text-center">
                <div><div className="text-[11px] text-slate-400">Monitored</div><div className="font-semibold text-slate-700">{total}</div></div>
                <div><div className="text-[11px] text-slate-400">Verified</div><div className="font-semibold text-emerald-600">{verified}</div></div>
                <div><div className="text-[11px] text-slate-400">Pending</div><div className="font-semibold text-amber-600">{pending}</div></div>
                <div><div className="text-[11px] text-slate-400">Exceptions</div><div className="font-semibold text-red-600">{exceptions}</div></div>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100 text-[12.5px] text-slate-500">
                Average verification time: <b className="text-slate-700">{avgMin != null ? fmtDuration(avgMin) : "Not enough verified records yet"}</b>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 p-5">
              <div className="text-[12px] text-slate-400 font-medium uppercase tracking-wide mb-3">Change-type breakdown</div>
              <div className="space-y-3">
                {breakdown.map(b => (
                  <div key={b.ct}>
                    <div className="flex justify-between text-[12.5px] mb-1">
                      <span className="text-slate-600">{b.ct}</span>
                      <span className="text-slate-500">{b.pct != null ? `${b.pct}% verified` : "No data"} <span className="text-slate-300">({b.count})</span></span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden">
                      <div className="h-full bg-indigo-500" style={{ width: `${b.pct || 0}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function InsightsPage({ records }) {
  if (records.length === 0) {
    return (
      <div>
        <PageHeader title="Insights" subtitle="Calculated only from recorded verification data — nothing here is estimated." />
        <div className="bg-white rounded-xl border border-slate-200 p-10 text-center text-slate-400 text-[13px]">No data yet — run verification on some expected changes first.</div>
      </div>
    );
  }

  const byType = CHANGE_TYPES.map(ct => {
    const sub = records.filter(r => r.changeType === ct);
    const resolved = sub.filter(r => r.status === "GREEN" || r.status === "RED");
    const exceptionRate = resolved.length ? Math.round((sub.filter(r => r.status === "RED").length / resolved.length) * 100) : null;
    const verifiedDurations = sub.filter(r => r.status === "GREEN" && r.verifiedAt).map(r => minutesBetween(new Date(r.createdAt), new Date(r.verifiedAt)));
    const avg = verifiedDurations.length ? Math.round(verifiedDurations.reduce((a, b) => a + b, 0) / verifiedDurations.length) : null;
    return { ct, exceptionRate, avg, count: sub.length };
  }).filter(b => b.count > 0);

  const worstException = [...byType].filter(b => b.exceptionRate != null).sort((a, b) => b.exceptionRate - a.exceptionRate)[0];
  const bestException = [...byType].filter(b => b.exceptionRate != null).sort((a, b) => a.exceptionRate - b.exceptionRate)[0];

  // repeat-exception locations
  const branchExceptions = {};
  records.forEach(r => { if (r.status === "RED") branchExceptions[`${r.client} — ${r.branch}`] = (branchExceptions[`${r.client} — ${r.branch}`] || 0) + 1; });
  const repeatLocations = Object.entries(branchExceptions).filter(([, n]) => n > 1).sort((a, b) => b[1] - a[1]);

  // client exception rates
  const clients = Array.from(new Set(records.map(r => r.client)));
  const clientRates = clients.map(c => {
    const sub = records.filter(r => r.client === c);
    const resolved = sub.filter(r => r.status === "GREEN" || r.status === "RED");
    const rate = resolved.length ? Math.round((sub.filter(r => r.status === "RED").length / resolved.length) * 100) : null;
    return { c, rate, count: sub.length };
  }).filter(c => c.rate != null);
  const avgClientRate = clientRates.length ? clientRates.reduce((a, b) => a + b.rate, 0) / clientRates.length : 0;
  const highClients = clientRates.filter(c => c.rate > avgClientRate + 10);

  const pendingCount = records.filter(r => r.status === "YELLOW").length;
  const exceptionCount = records.filter(r => r.status === "RED").length;

  return (
    <div>
      <PageHeader title="Insights" subtitle="Calculated only from recorded verification data — nothing here is estimated." />

      <div className="grid md:grid-cols-3 gap-3 mb-5">
        <MiniStat label="Pending changes" value={pendingCount} tone="YELLOW" />
        <MiniStat label="Open exceptions" value={exceptionCount} tone="RED" />
        <MiniStat label="Change types with data" value={byType.length} tone="slate" />
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5 mb-4">
        <div className="text-[13px] font-semibold text-slate-700 mb-3">Exception rate by change type</div>
        <div className="space-y-3">
          {byType.map(b => (
            <div key={b.ct}>
              <div className="flex justify-between text-[12.5px] mb-1">
                <span className="text-slate-600">{b.ct}</span>
                <span className="text-slate-500">{b.exceptionRate != null ? `${b.exceptionRate}% exception rate` : "Not enough resolved records"} · avg verify time {b.avg != null ? fmtDuration(b.avg) : "-"}</span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden">
                <div className="h-full bg-red-400" style={{ width: `${b.exceptionRate || 0}%` }} />
              </div>
            </div>
          ))}
        </div>
        {worstException && bestException && worstException.ct !== bestException.ct && (
          <div className="mt-4 pt-3 border-t border-slate-100 text-[12.5px] text-slate-600">
            <Sparkles size={13} className="inline text-indigo-500 mr-1" />
            {worstException.ct} changes have a higher exception rate ({worstException.exceptionRate}%) than {bestException.ct} changes ({bestException.exceptionRate}%) in the current data set.
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="text-[13px] font-semibold text-slate-700 mb-3">Locations with repeat exceptions</div>
          {repeatLocations.length === 0 ? (
            <div className="text-[12.5px] text-slate-400">No location has more than one exception yet.</div>
          ) : (
            <div className="space-y-2">
              {repeatLocations.map(([loc, n]) => (
                <div key={loc} className="flex justify-between text-[12.5px]"><span className="text-slate-600">{loc}</span><span className="font-semibold text-red-600">{n} exceptions</span></div>
              ))}
            </div>
          )}
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <div className="text-[13px] font-semibold text-slate-700 mb-3">Clients with above-average exception rates</div>
          {highClients.length === 0 ? (
            <div className="text-[12.5px] text-slate-400">No client is meaningfully above average right now.</div>
          ) : (
            <div className="space-y-2">
              {highClients.map(c => (
                <div key={c.c} className="flex justify-between text-[12.5px]"><span className="text-slate-600">{c.c}</span><span className="font-semibold text-red-600">{c.rate}%</span></div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function MiniStat({ label, value, tone }) {
  const meta = STATUS_META[tone];
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4">
      <div className="text-[12px] text-slate-500 font-medium mb-1">{label}</div>
      <div className="text-2xl font-bold" style={{ color: meta ? meta.text : "#0F172A" }}>{value}</div>
    </div>
  );
}

function AuditLogPage({ auditLog, onExport }) {
  return (
    <div>
      <PageHeader title="Audit Log" subtitle="Every verification action, recorded for accountability."
        right={<button onClick={() => onExport("audit_log.csv", auditLog.map(a => ({
          Timestamp: fmtDateTimeFull(a.timestamp), User: a.user, Client: a.client, Location: a.location,
          "Change Type": a.changeType, "Expected Value": a.expectedValue, "GBP Value": a.gbpValue,
          Result: a.result, "Attempt Number": a.attemptNumber, Source: a.source, "Action Taken": a.actionTaken, Notes: a.notes,
        })))} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[12.5px] font-medium border border-slate-200 text-slate-600 hover:bg-slate-50"><Download size={13} /> Export log</button>} />
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
          <table className="w-full text-[12px]">
            <thead className="sticky top-0 bg-slate-50">
              <tr className="text-slate-500 text-left border-b border-slate-200">
                {["Timestamp", "User", "Client", "Location", "Change Type", "Expected", "GBP Value", "Result", "Attempt", "Source", "Action Taken", "Notes"].map(h => <th key={h} className="px-3 py-2 font-semibold whitespace-nowrap bg-slate-50">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {auditLog.map(a => (
                <tr key={a.id} className="border-b border-slate-100">
                  <td className="px-3 py-2 whitespace-nowrap text-slate-500">{fmtDateTime(a.timestamp)}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{a.user}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{a.client}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{a.location}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{a.changeType}</td>
                  <td className="px-3 py-2 whitespace-nowrap max-w-[120px] truncate">{a.expectedValue}</td>
                  <td className="px-3 py-2 whitespace-nowrap max-w-[120px] truncate">{a.gbpValue ?? "-"}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{a.result}</td>
                  <td className="px-3 py-2 whitespace-nowrap text-center">{a.attemptNumber}</td>
                  <td className="px-3 py-2 whitespace-nowrap text-slate-500">{a.source}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{a.actionTaken}</td>
                  <td className="px-3 py-2 whitespace-nowrap text-slate-500 max-w-[160px] truncate">{a.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function SettingsPage({ settings, setSettings }) {
  return (
    <div>
      <PageHeader title="Settings" subtitle="Configure the recheck schedule and review the data-provider architecture." />

      <div className="bg-white rounded-xl border border-slate-200 p-5 mb-4 max-w-2xl">
        <div className="text-[13px] font-semibold text-slate-700 mb-3">Automatic recheck schedule</div>
        <div className="text-[12px] text-slate-500 mb-4">These are the real-world intervals a production backend scheduler would use. Attempt 1 fires this long after a change request is created; each following attempt fires this long after the previous one.</div>
        <div className="space-y-2">
          {settings.intervalsMinutes.map((m, i) => (
            <div key={i} className="flex items-center gap-3 text-[12.5px]">
              <span className="w-20 text-slate-500">Check {i + 1}</span>
              <input type="number" min="1" value={m === 60 * 18 ? 1080 : m}
                onChange={e => {
                  const v = Number(e.target.value) || 1;
                  setSettings(s => ({ ...s, intervalsMinutes: s.intervalsMinutes.map((x, xi) => xi === i ? v : x) }));
                }}
                className="w-24 px-2 py-1 rounded-md border border-slate-200" />
              <span className="text-slate-400">minutes ({fmtDuration(m)})</span>
            </div>
          ))}
        </div>
        <div className="flex items-center gap-3 mt-4 pt-4 border-t border-slate-100 text-[12.5px]">
          <span className="w-40 text-slate-500">Max attempts before Exception</span>
          <input type="number" min="1" value={settings.maxAttempts}
            onChange={e => setSettings(s => ({ ...s, maxAttempts: Number(e.target.value) || 1 }))}
            className="w-20 px-2 py-1 rounded-md border border-slate-200" />
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5 mb-4 max-w-2xl">
        <div className="text-[13px] font-semibold text-slate-700 mb-2">Live demo auto-check</div>
        <div className="text-[12px] text-slate-500 mb-3 leading-relaxed">
          This browser prototype has no backend job scheduler, so it cannot check Google in the background once the tab is closed. With this toggle on, pending records recheck themselves on a <b>compressed</b> timer (~10–35 seconds) while this tab stays open, so you can watch the pipeline work. Turn it off to freeze pending records exactly where they are.
        </div>
        <label className="flex items-center gap-2 text-[13px] font-medium text-slate-700">
          <input type="checkbox" checked={settings.demoAutoCheck} onChange={e => setSettings(s => ({ ...s, demoAutoCheck: e.target.checked }))} />
          Enable live demo auto-check (this tab only)
        </label>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5 max-w-2xl">
        <div className="text-[13px] font-semibold text-slate-700 mb-2">GBP data provider</div>
        <div className="text-[12.5px] text-slate-600 space-y-2 leading-relaxed">
          <p>The application reads GBP location data through a single interface, <code className="bg-slate-100 px-1 rounded">GBPDataProvider</code>, with three methods: <code className="bg-slate-100 px-1 rounded">getLocations()</code>, <code className="bg-slate-100 px-1 rounded">getLocation(id)</code>, and <code className="bg-slate-100 px-1 rounded">getLocationField(id, field)</code>.</p>
          <p><b>Active today:</b> <code className="bg-slate-100 px-1 rounded">FileUploadGBPProvider</code> — reads from the file you upload on the GBP Data page.</p>
          <p><b>Not connected:</b> a future <code className="bg-slate-100 px-1 rounded">GoogleBusinessProfileAPIProvider</code> would implement the same three methods against the live GBP API, so matching, comparison, the dashboard, and every other module would work unchanged. This requires GBP API credentials and access that this prototype does not have — nothing in this tool pretends that connection exists.</p>
        </div>
      </div>
    </div>
  );
}

function HelpPage() {
  const items = [
    { t: "How to upload expected changes", b: "Go to Expected Changes, then upload a CSV or Excel export from SI / V1 / V3 (or download the template first). Each row needs at minimum a Change Type, Old Value, Expected New Value, and enough identifying information to find the right location — ideally a GBP Location ID or Store Code." },
    { t: "How to upload GBP data", b: "Go to GBP Data and upload a Google Business Profile export or equivalent snapshot. This is the current-state data the comparison engine checks against. Re-upload periodically to refresh the snapshot." },
    { t: "How matching works", b: "Each expected change is matched to a GBP location using a hierarchy: GBP Location ID → Store Code → Internal Location ID → Phone → Business Name + Address. The method used is always shown. If no method reaches a confident match, the record is marked GRAY — Matching Required rather than risk comparing the wrong branch." },
    { t: "What Verified (GREEN) means", b: "The current GBP value, once normalized, matches the expected value. This is only ever shown when the actual uploaded/checked GBP data contains the expected value — never assumed." },
    { t: "What Pending (YELLOW) means", b: "The expected value has not yet appeared on Google, and the record is still within the allowed number of recheck attempts. It will be checked again automatically." },
    { t: "What Exception (RED) means", b: "The expected value still did not appear after the maximum number of recheck attempts. This is the list Ops should work from — it does not mean SI is wrong, only that the change is not yet reflected on Google and needs a look." },
    { t: "How automatic rechecking works", b: "In production, a backend job scheduler would recheck each pending record at the intervals configured in Settings (default: 30 min, 2h, 6h, next business day) until it verifies or exhausts the max attempts. This browser prototype has no backend, so it simulates the same pipeline on a compressed timer while the tab is open (Settings → Live demo auto-check). You can also trigger a check manually with Retry Verification." },
    { t: "How to export the report", b: "Use the Export button in the top bar for the full report, or the Export buttons on the Exceptions and Audit Log pages for a scoped export. All exports download as CSV." },
  ];
  return (
    <div>
      <PageHeader title="Help" subtitle="What this tool does, and how it fits alongside SI." />
      <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-4 mb-5 text-[13px] text-indigo-900 leading-relaxed">
        This solution complements the existing SI Out of Sync functionality. It is designed specifically for operational verification of requested GBP changes and exception monitoring — it does not sync, replace, or second-guess SI's data.
      </div>
      <div className="space-y-3">
        {items.map((it, i) => (
          <details key={i} className="bg-white rounded-xl border border-slate-200 p-4 group" open={i === 0}>
            <summary className="text-[13.5px] font-semibold text-slate-800 cursor-pointer list-none flex items-center justify-between">
              {it.t} <ChevronDown size={15} className="text-slate-400 group-open:rotate-180 transition-transform" />
            </summary>
            <p className="text-[12.5px] text-slate-600 mt-2 leading-relaxed">{it.b}</p>
          </details>
        ))}
      </div>
    </div>
  );
}

function DetailPage({ record: r, onBack, onRetry, onReview, onNote, onAssign, onSimulateGoogleUpdate, settings }) {
  const [noteText, setNoteText] = useState("");
  const [assignee, setAssignee] = useState("");
  const fieldKey = FIELD_KEY[r.changeType];
  const normalizer = NORMALIZER[r.changeType];
  const rawMismatch = r.currentGbpValue != null && normalizer(r.currentGbpValue) !== normalizer(r.expectedValue);

  return (
    <div className="max-w-4xl">
      <button onClick={onBack} className="flex items-center gap-1.5 text-[12.5px] text-slate-500 hover:text-slate-800 mb-4">
        <ArrowLeft size={14} /> Back
      </button>

      <div className="flex items-start justify-between flex-wrap gap-3 mb-1">
        <div>
          <div className="text-[12px] text-slate-400 font-medium">{r.client} — {r.branch}</div>
          <h1 className="text-[20px] font-bold text-slate-900">{r.changeType} Verification</h1>
        </div>
        <StatusBadge status={r.status} />
      </div>
      {r.unexpectedChange && (
        <div className="mt-3 p-3 rounded-lg bg-amber-50 border border-amber-200 text-[12.5px] text-amber-800 flex gap-2">
          <AlertTriangle size={15} className="shrink-0 mt-0.5" />
          <div>
            <b>Unexpected change detected.</b> Expected: {r.changeType} update {r.status === "GREEN" ? "✓" : ""}. Detected: <b>{r.unexpectedChange.field}</b> changed from "{r.unexpectedChange.from}" to "{r.unexpectedChange.to}". This is shown for review — it is not automatically classified as an error.
          </div>
        </div>
      )}

      <div className="grid sm:grid-cols-3 gap-3 my-5">
        <ValueCard label="Old Value" value={r.oldValue} />
        <ValueCard label="Expected Value" value={r.expectedValue} />
        <ValueCard label="Current GBP Value" value={r.currentGbpValue ?? (r.status === "GRAY" ? "Waiting for GBP data" : (r.isDemo ? "Demo Data" : "Waiting for GBP data"))} highlight />
      </div>

      {rawMismatch && (
        <div className="bg-white rounded-xl border border-slate-200 p-4 mb-5">
          <div className="text-[12px] font-semibold text-slate-500 uppercase tracking-wide mb-2">Raw vs. normalized comparison</div>
          <div className="grid grid-cols-2 gap-4 text-[12.5px]">
            <div>
              <div className="text-slate-400 mb-1">Raw</div>
              <div className="text-slate-700">Expected: <span className="font-mono">{r.expectedValue}</span></div>
              <div className="text-slate-700">GBP: <span className="font-mono">{r.currentGbpValue}</span></div>
            </div>
            <div>
              <div className="text-slate-400 mb-1">Normalized</div>
              <div className="text-slate-700">Expected: <span className="font-mono">{normalizer(r.expectedValue)}</span></div>
              <div className="text-slate-700">GBP: <span className="font-mono">{normalizer(r.currentGbpValue)}</span></div>
            </div>
          </div>
        </div>
      )}

      <div className="grid sm:grid-cols-2 gap-4 mb-5">
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="text-[12px] font-semibold text-slate-500 uppercase tracking-wide mb-2">Match</div>
          <div className="text-[13px] text-slate-700">Matched using: <b>{r.matchMethod}</b></div>
          <div className="text-[12px] text-slate-400 mt-1">Confidence: {r.matchConfidence}</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <div className="text-[12px] font-semibold text-slate-500 uppercase tracking-wide mb-2">Verification source</div>
          <div className="text-[13px] text-slate-700">{r.source} {r.isDemo && <span className="text-amber-600 font-medium">(Demo Data)</span>}</div>
          {r.status === "GREEN" && r.verifiedAt && <div className="text-[12px] text-slate-400 mt-1">Verified at {fmtDateTimeFull(r.verifiedAt)}</div>}
        </div>
      </div>

      {/* TIMELINE */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 mb-5">
        <div className="text-[12px] font-semibold text-slate-500 uppercase tracking-wide mb-3">Verification timeline</div>
        <div className="space-y-0">
          {r.checks.map((c, i) => (
            <div key={i} className="flex gap-3 relative">
              <div className="flex flex-col items-center">
                <div className={`w-2.5 h-2.5 rounded-full mt-1 ${c.result === "VERIFIED" ? "bg-emerald-500" : c.result === "EXCEPTION" ? "bg-red-500" : c.result === "PENDING" ? "bg-amber-500" : "bg-slate-300"}`} />
                {i < r.checks.length - 1 && <div className="w-px flex-1 bg-slate-200" />}
              </div>
              <div className="pb-4">
                <div className="text-[12px] text-slate-400">{fmtDateTime(c.time)}</div>
                <div className="text-[13px] text-slate-700 font-medium">{c.n === 0 ? c.event : `Check #${c.n}`}</div>
                {c.n > 0 && (
                  <div className="text-[12.5px] text-slate-500 mt-0.5">
                    GBP {c.result === "VERIFIED" ? "shows expected value" : "still shows previous value"}: <span className="font-mono">{c.gbpValue}</span> — <span className={c.result === "VERIFIED" ? "text-emerald-600 font-semibold" : c.result === "EXCEPTION" ? "text-red-600 font-semibold" : "text-amber-600 font-semibold"}>{c.result}</span>
                  </div>
                )}
              </div>
            </div>
          ))}
          {r.status === "YELLOW" && (
            <div className="text-[12px] text-slate-400 pl-5 ml-0.5">
              {settings.demoAutoCheck ? "Next check scheduled — simulated timing (see Settings)." : "Auto-check paused (Settings → Live demo auto-check is off)."}
            </div>
          )}
        </div>
      </div>

      {/* ACTIONS */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 mb-5">
        <div className="text-[12px] font-semibold text-slate-500 uppercase tracking-wide mb-3">Actions</div>
        <div className="flex flex-wrap gap-2 mb-3">
          {r.status === "RED" && !r.reviewed && <button onClick={() => onReview(r.id)} className="px-3 py-1.5 rounded-md border border-slate-200 text-[12.5px] font-medium text-slate-600 hover:bg-slate-50">Mark as Reviewed</button>}
          {(r.status === "RED" || r.status === "YELLOW") && <button onClick={() => onRetry(r.id)} className="px-3 py-1.5 rounded-md border border-slate-200 text-[12.5px] font-medium text-slate-600 hover:bg-slate-50 inline-flex items-center gap-1"><RefreshCw size={13} /> Retry Verification</button>}
          {r.status === "YELLOW" && r.matchedLocationId && (
            <button onClick={() => onSimulateGoogleUpdate(r.id)} className="px-3 py-1.5 rounded-md border border-dashed border-indigo-300 text-[12.5px] font-medium text-indigo-600 hover:bg-indigo-50">
              Demo: Simulate Google update
            </button>
          )}
          <button onClick={() => downloadCSV(`record_${r.id}.csv`, [exportRow(r)])} className="px-3 py-1.5 rounded-md border border-slate-200 text-[12.5px] font-medium text-slate-600 hover:bg-slate-50 inline-flex items-center gap-1"><Download size={13} /> Export</button>
        </div>

        <div className="flex gap-2 mb-3">
          <input value={assignee} onChange={e => setAssignee(e.target.value)} placeholder="Assign to team member…"
            className="flex-1 px-3 py-1.5 rounded-md border border-slate-200 text-[12.5px]" />
          <button onClick={() => { if (assignee.trim()) { onAssign(r.id, assignee); setAssignee(""); } }}
            className="px-3 py-1.5 rounded-md border border-slate-200 text-[12.5px] font-medium text-slate-600 hover:bg-slate-50">Assign</button>
        </div>
        {r.assignedTo && <div className="text-[12px] text-slate-500 mb-3">Currently assigned to <b>{r.assignedTo}</b></div>}

        <div className="flex gap-2">
          <input value={noteText} onChange={e => setNoteText(e.target.value)} placeholder="Add a note…"
            className="flex-1 px-3 py-1.5 rounded-md border border-slate-200 text-[12.5px]" />
          <button onClick={() => { onNote(r.id, noteText); setNoteText(""); }}
            className="px-3 py-1.5 rounded-md bg-indigo-600 text-white text-[12.5px] font-semibold hover:bg-indigo-700 inline-flex items-center gap-1"><PlusCircle size={13} /> Add Note</button>
        </div>
        {(r.notes || []).length > 0 && (
          <div className="mt-3 space-y-2">
            {r.notes.map((n, i) => (
              <div key={i} className="text-[12.5px] bg-slate-50 rounded-md p-2.5 border border-slate-100">
                <div className="text-slate-400 text-[11px] mb-0.5">{fmtDateTime(n.time)} · {n.author}</div>
                <div className="text-slate-700">{n.text}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ValueCard({ label, value, highlight }) {
  return (
    <div className={`rounded-xl border p-4 ${highlight ? "border-indigo-200 bg-indigo-50/40" : "border-slate-200 bg-white"}`}>
      <div className="text-[11px] text-slate-400 font-semibold uppercase tracking-wide mb-1">{label}</div>
      <div className="text-[14px] font-semibold text-slate-800 break-words">{value || "-"}</div>
    </div>
  );
}
